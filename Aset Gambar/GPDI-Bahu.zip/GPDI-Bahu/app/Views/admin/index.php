<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>

<body>
    <h1>Halaman Admin</h1>
    <hr>
    <h2>Halo <?php echo session()->get('name') ?></h2>
    <hr>
    <h2>Kamu Sebagai <?php echo session()->get('level') ?></h2>

    <hr>
    <a href="<?php echo base_url('/logout'); ?>">Logout</a>
    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <h3>Konfirmasi Logout</h3>
            <p>Apakah Anda yakin ingin keluar?</p>
            <button onclick="logout()">Ya, Logout</button>
            <button onclick="closeModal()">Batal</button>
        </div>
    </div>

    <a href="#" onclick="openModal()">Logout</a>

    <script>
        function openModal() {
            document.getElementById('logoutModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('logoutModal').style.display = 'none';
        }

        function logout() {
            window.location.href = '<?php echo base_url('/logout'); ?>';
        }
    </script>

    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 300px;
            text-align: center;
        }

        button {
            margin: 10px;
            padding: 5px 10px;
        }
    </style>
</body>

</html>