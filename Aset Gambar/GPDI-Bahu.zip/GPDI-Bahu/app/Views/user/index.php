<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
</head>

<body>
    <?php
    if (session()->getFlashdata('pesan')) {
        echo '<div class="alert alert-danger">' . session()->getFlashdata('pesan') . '</div>';
    }
    ?>

    <h1>Halaman User</h1>
    <hr>
    <h2>Halo <?php echo session()->get('name') ?></h2>
    <hr>
    <h2>Kamu Sebagai <?php echo session()->get('level') ?></h2>

    <hr>
    <a href="<?php echo base_url('/logout'); ?>">Logout</a>

</body>

</html>