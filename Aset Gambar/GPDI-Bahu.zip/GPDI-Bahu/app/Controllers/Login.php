<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\UsersModel;

class Login extends BaseController
{
    public function index()
    {
        return view('login');
    }

    public function loginAction()
    {
        $session = session();
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $userCek = new UsersModel();
        $cek = $userCek->where('username', $username)->first();

        if ($cek) {
            $checkPassword = password_verify($password, $cek['password']);
            if ($checkPassword) {
                $sessData = [
                    'id' => $cek['id'],
                    'username' => $cek['username'],
                    'name' => $cek['name'],
                    'level' => $cek['level'],
                    'logged_in' => TRUE,
                ];
                $session->set($sessData);
                switch ($cek['level']) {
                    case 'admin':
                        return redirect()->to('/admin');
                        break;
                    case 'user':
                        return redirect()->to('/user');
                        break;
                    default:
                        session()->setFlashdata('pesan', 'Login gagal!, Akun Belum Terdaftar!');
                        return redirect()->to('/login');
                        break;
                }
            } else {
                session()->setFlashdata('pesan', 'Login Gagal!, Password Salah!');
                return redirect()->to('/login');
            }
        } else {
            session()->setFlashdata('pesan', 'Login gagal!, Username Tidak Ditemukan!');
            return redirect()->to('/login');
        }
    }

    public function logout()
    {
        $session = session();
        $session->destroy();

        // Check if the session was successfully destroyed
        if (session_status() === PHP_SESSION_NONE || empty(session()->get())) {
            // Session was successfully destroyed
            return redirect()->to('/login')->with('message', 'You have been successfully logged out.');
        } else {
            // Session destruction failed
            log_message('error', 'Session destruction failed during logout.');
            return redirect()->to('/login')->with('error', 'Logout failed. Please try again.');
        }
    }
}
